library(stringr)

## make an new folder for the project

make.new.project.folder <- function(project.name){
    path.to.project <- choose.dir()
    dir.create(paste0(path.to.project,"/" , project.name))
    print("Project folder >>> DONE")
    return(paste0(path.to.project,"/" , project.name))
}


## make the confg file for auto dock

upload.receptor <- function(project.path, DB = F){
    
    if (DB == T){
        project.path <- str_replace_all(project.path, fixed("\\"), fixed("/") )
        pdb.files <- list.files("DB/" , pattern = ".pdbqt" , full.names = T)
        for (i.pdb in pdb.files){
            file.copy(i.pdb, project.path,overwrite = T, recursive = F)
        }
    }else{
        project.path <- str_replace_all(project.path, fixed("\\"), fixed("/") )
        pdb.files <- choose.files()
        for (i.pdb in pdb.files){
            file.copy(i.pdb, project.path,overwrite = T, recursive = F)
        }
        print("Receptor files >>> DONE")
    }
}


upload.ligand <- function(project.path){
    
    project.path <- str_replace_all(project.path, fixed("\\"), fixed("/") )
    pdb.files <- choose.files()
    
    file.copy(pdb.files, project.path, overwrite = T, recursive = F)
    print("Ligand file >>> DONE")
    return(basename(pdb.files))
}


make.conf.autodock <- function(project.path , DB = F, ligand.name){
    if (DB == T){
        conf.df <- read.csv("DB/DB_DF.csv")
        ligand.name <- str_remove_all(ligand.name, fixed(".pdbqt"))
        conf.df$ligand <- rep(ligand.name , nrow(conf.df))
    }
    if (DB == F){
        conf.df <- read.csv(choose.files())
    }
    project.path <- str_replace_all(project.path, fixed("\\"), fixed("/") )
    file.copy("autodock/vina.exe", project.path, overwrite = T, recursive = F)
    for(i.conf in 1:nrow(conf.df)){
        read.conf <- readLines("autodock/docking.conf")
        read.conf <- str_replace( read.conf, fixed("re_x"), paste0(conf.df[i.conf,1] , ".pdbqt"))
        read.conf <- str_replace( read.conf, fixed("l_x"), paste0(conf.df[i.conf,2], ".pdbqt"))
        
        read.conf <- str_replace( read.conf, fixed("c_x"), conf.df[i.conf,3])
        read.conf <- str_replace( read.conf, fixed("c_y"), conf.df[i.conf,4])
        read.conf <- str_replace( read.conf, fixed("c_z"), conf.df[i.conf,5])
        
        read.conf <- str_replace( read.conf, fixed("s_x"), conf.df[i.conf,6])
        read.conf <- str_replace( read.conf, fixed("s_y"), conf.df[i.conf,7])
        read.conf <- str_replace( read.conf, fixed("s_z"), conf.df[i.conf,8])
        
        read.conf <- str_replace( read.conf, fixed("out_x"), paste0(conf.df[i.conf,1], "_result.pdbqt"))
        
        
        writeLines(read.conf , paste0(project.path, "/" , conf.df[i.conf,1], ".conf") )
        
        project.path <- str_replace_all(project.path, fixed("/"), fixed("\\") )
        
        #chnage_dir <- file.path(paste0("pushd " , '"' ,project.path , '"'))
        #chnage_dir <- str_replace(chnage_dir , fixed("\\") , "")
        
        run_shell <- paste0("vina.exe --config ", conf.df[i.conf,1], ".conf")
        
        write(run_shell, paste0(project.path,"/run.bat"))
        
        shell(paste0("pushd ",project.path, " && ", project.path, "\\run.bat"), wait = T)
        #system(paste0('pushd "D:\\Ali\\nile project\\test1\\"', "&&" ,'"',project.path,"\\run.bat", '"'))
    }
    
}


## parse result

parse.result <- function(project.path){
    get.result.files <- list.files(project.path , pattern = "_result", full.names = T)
    
    all.results <- ""
    for (i.read in get.result.files){
        read.result <- readLines(i.read)
        read.result <- read.result[1:2]
        receptor.name <- str_remove_all(basename(i.read) , fixed("_result.pdbqt"))
        read.result[1] <- paste0(receptor.name, " affinity(Kcal/mol) | rmsd l.b. | rmsd u.b.")
        
        model.result <- paste(read.result , collapse = "\n")
        
        cat(model.result)
        cat("\n")
        all.results <- paste(all.results , "\n" , model.result)
    }
    
    write(all.results , paste0(project.path ,"\\summary_output.txt"))
    
}

result.df <- function(project.path){
    result.df <- readLines(paste0(project.path,"/summary_output.txt"))
    result.df <- result.df[c(3,5,7,9,11)]
    result.df <- str_replace_all(result.df , " ", "\t")
    result.df <- str_split(result.df, "\t")
    
    final.df <- data.frame(receptor = c("1DNU","1N8Q","1OG5","2CDU", "2ckj"),
                           `affinity(Kcal/mol)` =  rep("NONE",5),
                           `rmsd l.b.` = rep("NONE",5),
                           `rmsd u.b.` = rep("NONE",5))
    
    count <- 0
    for(i in result.df){
        count <- count + 1
        c.df <- c()
        for (j in i){
            if(!is.na(as.numeric(j))){
                c.df <- c(c.df , as.numeric(j))
            }
        }
        final.df[count, c(2,3,4)] <- c.df
    }
    
    return(final.df)
}

#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(shinycustomloader)
library(shinyFiles)
library(rhandsontable)
library(shinythemes)
library(shinyalert)
# Define UI for application 
ui <- fluidPage(

    # Application title
    titlePanel("Docken"),
    useShinyalert(),
    sidebarLayout(
        sidebarPanel(width = 3,
            
            shinyjs::useShinyjs(),
            
            actionButton("about_us", "About US", class = "btn-success", 
                         style='padding:10px; font-size:100%; margin-top:0.5em', 
                                          width = 200, icon = icon("address-card")),
            
            actionButton("cite_us", "Cite US", class = "btn-success", 
                         style='padding:10px; font-size:100%; margin-top:0.5em', 
                         width = 200, icon = icon("scroll")),
            
            actionButton("how_it_work", "How it work?", class = "btn-success", 
                         style='padding:10px; font-size:100%; margin-top:0.5em', 
                         width = 200, icon = icon("users-cog")),
            
            actionButton("how_to_use", "How to use it?", class = "btn-success", 
                         style='padding:10px; font-size:100%; margin-top:0.5em', 
                         width = 200, icon = icon("users-cog")),
            
            actionButton("start_docken", "Start Docken", class = "btn btn-primary", 
                         style='padding:10px; font-size:100%; margin-top:0.5em', 
                         width = 200, icon = icon("users-cog")),
            
            actionButton("reload_docken", "Reload Docken", class = "btn btn-primary", 
                         style='padding:10px; font-size:100%; margin-top:0.5em', 
                         width = 200, icon = icon("users-cog")),
            textInput("project.name","Enter the Project Name:"),
            
            # radioButtons("use.DB", "Use Our Receptors",
            #              c("Yes" = "yes",
            #                "No" = "no"))
                             
            ),
        
        mainPanel(
            tabsetPanel(id = "inTabset",
                        
                        tabPanel("Welcome To Docken",
                                 value = "welcome",
                                 img(src='https://raw.githubusercontent.com/AliYoussef96/Docken/main/workflow.png', align = "center") ),
                        
                        tabPanel("About Us",
                                 value = "about.us",
                                 includeMarkdown("https://raw.githubusercontent.com/AliYoussef96/Docken/main/About%20US.md")),
                        
                        tabPanel("Cite Us",
                                 value = "cite.us"),
                        
                        tabPanel("How it work?",
                                 value = "how.it.work",
                                 img(src='https://raw.githubusercontent.com/AliYoussef96/Docken/main/workflow.png', align = "center")),
                        
                        
                        tabPanel("Result Docken", 
                                 withLoader(dataTableOutput("output_result_df"),
                                                             type="html", loader="loader2"), 
                                 value = "start.docken")
                        )
       
        )
    )
)


# Define server logic required to draw a histogram
server <- function(input, output, session) {
    
    ## close 
    observe({
        if(input$reload_docken > 0){
            session$reload()
        }
    })
    
    observe({
        if(input$about_us > 0){
            
            observeEvent(input$about_us, {
                updateTabsetPanel(session, "inTabset",selected = "about.us")
            })
            
        }
    })
    
    observe({
        if(input$cite_us > 0){
            
            observeEvent(input$cite_us, {
                updateTabsetPanel(session, "inTabset",selected = "cite.us")
            })
            
        }
    })
    
    observe({
        if(input$how_it_work > 0){
            
            observeEvent(input$how_it_work, {
                updateTabsetPanel(session, "inTabset",selected = "how.it.work")
            })
            
        }
    })
    
    observe({
        if(input$start_docken > 0){


                shinyalert("Project folder", "Choose where to save your project", type = "info")
                
                Sys.sleep(2)
                
                project.name <- input$project.name
                
                project.path <- make.new.project.folder(project.name)
                
                upload.receptor(project.path , DB = T)
                
                shinyalert("Ligand", "Upload your pdbqt ligand file", type = "info")
                
                Sys.sleep(3)
                
                ligand.name <- upload.ligand(project.path)
                
                
                shinyalert("Please wait!!", "Loading...", type = "info")
                
                make.conf.autodock(project.path, DB = T, ligand.name)
                
                parse.result(project.path)
                
                output$output_result_df <- renderDataTable({result.df(project.path)})
                
                observeEvent(input$start_docken, {
                    updateTabsetPanel(session, "inTabset",selected = "start.docken")
                })
            
        }
    })

}

# Run the application 
shinyApp(ui = ui, server = server)
